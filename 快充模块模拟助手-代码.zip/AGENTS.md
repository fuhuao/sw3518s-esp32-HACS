# SW3518S MQTT 模拟器

PC 端浏览器工具，模拟 ESP32-S3 + SW3518S PD 快充充电器模块，通过 MQTT 与 Home Assistant 通信，用于测试 HA 集成链路。

## 技术栈

- 纯前端应用，浏览器端 MQTT over WebSocket
- mqtt.js 作为 MQTT 客户端库
- React + TypeScript + Tailwind CSS

## 功能模块

1. MQTT 连接配置区（broker 地址、端口、用户名、密码、主题前缀、连接状态）
2. 状态发送区（字段编辑 + 手动发送 + 自动上报开关/间隔）
3. 控制信号指示灯区（输出开关灯 + 5 个协议指示灯，红绿双色）
4. 消息日志区（收发原始 JSON + 时间戳 + 主题 + 方向）

## 协议字段约定（严格大小写敏感）

### 状态上报 (state topic)
- `vout_mv`: int, 输出电压 mV
- `iout_c_ma`: int, C 口输出电流 mA
- `power_w`: float, 输出功率 W
- `temp_c`: float, 芯片温度 ℃
- `proto_name`: string, 快充协议名称
- `output_en`: bool, 输出开关状态
- `proto_en`: object, 各协议启用状态 { pd, qc, scp, vooc, fcp }

### 控制指令 (cmd topic)
- `{"cmd":"output_on"}` → 输出开
- `{"cmd":"output_off"}` → 输出关
- `{"cmd":"set_proto","proto":"pd","enable":true/false}` → 设置协议启用

### 协议名称枚举
PD3.0-PPS / PD2.0 / QC4+ / QC3.0 / QC2.0 / SCP / VOOC / FCP / NONE

## 设计规范

- 布局：顶部连接配置 → 中部左（状态发送）+ 右（指示灯）→ 底部日志
- 指示灯：圆形、大号、红绿分明、带发光效果
- 日志：等宽字体、深色背景、发送绿色 / 接收蓝色标识
- 整体风格：技术工具风，深色主题
