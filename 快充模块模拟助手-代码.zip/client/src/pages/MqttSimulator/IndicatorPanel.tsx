import { Lightbulb } from 'lucide-react';
import type { ProtoEnable, ProtoKey } from './types';
import { PROTO_KEY_LABELS } from './types';

interface IndicatorPanelProps {
  outputEn: boolean;
  protoEn: ProtoEnable;
}

const IndicatorLight = ({
  label,
  active,
  activeColor = 'green',
}: {
  label: string;
  active: boolean;
  activeColor?: 'green' | 'red';
}) => {
  const activeGlow =
    activeColor === 'green'
      ? 'shadow-[0_0_20px_rgba(34_197_94_0.7),0_0_40px_rgba(34_197_94_0.4)] bg-green-500'
      : 'shadow-[0_0_20px_rgba(239_68_68_0.7),0_0_40px_rgba(239_68_68_0.4)] bg-red-500';
  const inactiveBg = 'bg-slate-700';

  return (
    <div className="flex flex-col items-center gap-2">
      <div
        className={`w-14 h-14 rounded-full transition-all duration-300 ${
          active ? activeGlow : inactiveBg
        }`}
      />
      <span className="text-sm font-medium text-slate-300">{label}</span>
      <span
        className={`text-xs font-semibold ${
          active
            ? activeColor === 'green'
              ? 'text-green-400'
              : 'text-red-400'
            : 'text-slate-500'
        }`}
      >
        {active ? (activeColor === 'green' ? 'ON' : 'OFF') : '--'}
      </span>
    </div>
  );
};

const IndicatorPanel = ({ outputEn, protoEn }: IndicatorPanelProps) => {
  const protoKeys: ProtoKey[] = ['pd', 'qc', 'scp', 'vooc', 'fcp'];

  return (
    <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 backdrop-blur h-full flex flex-col">
      <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
        <Lightbulb className="w-5 h-5 text-amber-400" />
        控制信号指示
      </h2>

      <div className="flex-1 flex flex-col justify-center">
        <div className="mb-6">
          <h3 className="text-sm text-slate-400 mb-3 text-center">输出开关</h3>
          <div className="flex items-center justify-center gap-8">
            <IndicatorLight
              label="绿灯 (开)"
              active={outputEn}
              activeColor="green"
            />
            <IndicatorLight
              label="红灯 (关)"
              active={!outputEn}
              activeColor="red"
            />
          </div>
        </div>

        <div className="pt-4 border-t border-slate-700">
          <h3 className="text-sm text-slate-400 mb-3 text-center">协议状态</h3>
          <div className="grid grid-cols-5 gap-2">
            {protoKeys.map((proto) => (
              <div key={proto} className="flex flex-col items-center gap-1.5">
                <div
                  className={`w-10 h-10 rounded-full transition-all duration-300 ${
                    protoEn[proto]
                      ? 'shadow-[0_0_15px_rgba(34_197_94_0.6)] bg-green-500'
                      : 'bg-slate-700'
                  }`}
                />
                <span className="text-xs font-mono text-slate-400 uppercase">
                  {PROTO_KEY_LABELS[proto]}
                </span>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-500 text-center mt-3">
            亮绿 = 启用 · 暗灰 = 禁用
          </p>
        </div>
      </div>
    </div>
  );
};

export default IndicatorPanel;
