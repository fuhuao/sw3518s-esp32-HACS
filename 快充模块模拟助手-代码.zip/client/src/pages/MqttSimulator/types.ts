export interface ChargerState {
  vout_mv: number;
  iout_c_ma: number;
  power_w: number;
  temp_c: number;
  proto_name: string;
  output_en: boolean;
  proto_en: ProtoEnable;
}

export interface ProtoEnable {
  pd: boolean;
  qc: boolean;
  scp: boolean;
  vooc: boolean;
  fcp: boolean;
}

export type ProtoKey = keyof ProtoEnable;

export const PROTOCOL_NAMES = [
  'PD3.0-PPS',
  'PD2.0',
  'QC4+',
  'QC3.0',
  'QC2.0',
  'SCP',
  'VOOC',
  'FCP',
  'NONE',
] as const;

export type ProtoName = typeof PROTOCOL_NAMES[number];

export interface OutputCmd {
  cmd: 'output_on' | 'output_off';
}

export interface SetProtoCmd {
  cmd: 'set_proto';
  proto: ProtoKey;
  enable: boolean;
}

export type ChargerCmd = OutputCmd | SetProtoCmd;

export interface MqttConfig {
  broker: string;
  port: number;
  username: string;
  password: string;
  topicPrefix: string;
  useSSL: boolean;
}

export type ConnectionStatus =
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'error'
  | 'reconnecting';

export interface LogEntry {
  id: string;
  timestamp: Date;
  topic: string;
  direction: 'send' | 'recv';
  payload: string;
}

export const DEFAULT_MQTT_CONFIG: MqttConfig = {
  broker: 'broker.emqx.io',
  port: 8084,
  username: '',
  password: '',
  topicPrefix: 'home/sw3518s_charger',
  useSSL: true,
};

export const DEFAULT_CHARGER_STATE: ChargerState = {
  vout_mv: 12120,
  iout_c_ma: 2450,
  power_w: 29.69,
  temp_c: 47.5,
  proto_name: 'PD3.0-PPS',
  output_en: true,
  proto_en: {
    pd: true,
    qc: true,
    scp: false,
    vooc: false,
    fcp: true,
  },
};

export const PROTO_KEY_LABELS: Record<ProtoKey, string> = {
  pd: 'PD',
  qc: 'QC',
  scp: 'SCP',
  vooc: 'VOOC',
  fcp: 'FCP',
};
