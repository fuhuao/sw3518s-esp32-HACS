import { useState } from 'react';
import { Send, Play, Pause, Zap } from 'lucide-react';
import type { ChargerState } from './types';
import { PROTOCOL_NAMES } from './types';

interface StatePanelProps {
  state: ChargerState;
  onStateChange: (state: ChargerState) => void;
  autoReport: boolean;
  reportInterval: number;
  onAutoReportChange: (enabled: boolean, interval: number) => void;
  onSend: () => void;
  connected: boolean;
}

const StatePanel = ({
  state,
  onStateChange,
  autoReport,
  reportInterval,
  onAutoReportChange,
  onSend,
  connected,
}: StatePanelProps) => {
  const [intervalInput, setIntervalInput] = useState(String(reportInterval));

  const handleNumChange = (field: keyof ChargerState, value: string) => {
    const num = parseFloat(value);
    if (isNaN(num) && value !== '' && value !== '-') return;
    onStateChange({ ...state, [field]: value === '' ? 0 : num });
  };

  const handleBoolChange = (field: 'output_en', value: boolean) => {
    onStateChange({ ...state, [field]: value });
  };

  const handleProtoChange = (proto: keyof ChargerState['proto_en'], value: boolean) => {
    onStateChange({
      ...state,
      proto_en: { ...state.proto_en, [proto]: value },
    });
  };

  const handleIntervalChange = (value: string) => {
    setIntervalInput(value);
    const num = parseInt(value, 10);
    if (!isNaN(num) && num > 0) {
      onAutoReportChange(autoReport, num);
    }
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 backdrop-blur h-full flex flex-col">
      <h2 className="text-lg font-semibold text-white flex items-center gap-2 mb-4">
        <Zap className="w-5 h-5 text-yellow-400" />
        状态发送（{state.proto_en.pd ? 'state' : 'state'}/topic）
      </h2>

      <div className="space-y-3 flex-1">
        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs text-slate-400 mb-1">
              vout_mv <span className="text-slate-500">(mV)</span>
            </label>
            <input
              type="number"
              value={state.vout_mv}
              onChange={(e) => handleNumChange('vout_mv', e.target.value)}
              className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              iout_c_ma <span className="text-slate-500">(mA)</span>
            </label>
            <input
              type="number"
              value={state.iout_c_ma}
              onChange={(e) => handleNumChange('iout_c_ma', e.target.value)}
              className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              power_w <span className="text-slate-500">(W)</span>
            </label>
            <input
              type="number"
              step="0.01"
              value={state.power_w}
              onChange={(e) => handleNumChange('power_w', e.target.value)}
              className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-400 mb-1">
              temp_c <span className="text-slate-500">(℃)</span>
            </label>
            <input
              type="number"
              step="0.1"
              value={state.temp_c}
              onChange={(e) => handleNumChange('temp_c', e.target.value)}
              className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs text-slate-400 mb-1">proto_name</label>
          <select
            value={state.proto_name}
            onChange={(e) => onStateChange({ ...state, proto_name: e.target.value })}
            className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500"
          >
            {PROTOCOL_NAMES.map((name) => (
              <option key={name} value={name}>
                {name}
              </option>
            ))}
          </select>
        </div>

        <div className="flex items-center justify-between px-3 py-2 bg-slate-900/40 rounded-lg border border-slate-700">
          <span className="text-sm text-slate-300">output_en</span>
          <button
            type="button"
            onClick={() => handleBoolChange('output_en', !state.output_en)}
            className={`relative w-12 h-6 rounded-full transition-colors ${
              state.output_en ? 'bg-green-500' : 'bg-slate-600'
            }`}
          >
            <span
              className={`absolute top-0.5 w-5 h-5 bg-white rounded-full transition-transform ${
                state.output_en ? 'translate-x-6' : 'translate-x-0.5'
              }`}
            />
          </button>
        </div>

        <div>
          <label className="block text-xs text-slate-400 mb-2">proto_en</label>
          <div className="grid grid-cols-5 gap-2">
            {(['pd', 'qc', 'scp', 'vooc', 'fcp'] as const).map((proto) => (
              <button
                key={proto}
                type="button"
                onClick={() => handleProtoChange(proto, !state.proto_en[proto])}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-lg border text-xs font-mono uppercase transition-colors ${
                  state.proto_en[proto]
                    ? 'bg-green-500/20 border-green-500 text-green-400'
                    : 'bg-slate-900/40 border-slate-600 text-slate-400'
                }`}
              >
                {proto}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="pt-4 mt-3 border-t border-slate-700 space-y-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onAutoReportChange(!autoReport, reportInterval)}
            disabled={!connected}
            className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${
              autoReport
                ? 'bg-orange-600 hover:bg-orange-500 text-white'
                : 'bg-slate-700 hover:bg-slate-600 text-slate-200'
            }`}
          >
            {autoReport ? (
              <>
                <Pause className="w-4 h-4" />
                停止上报
              </>
            ) : (
              <>
                <Play className="w-4 h-4" />
                自动上报
              </>
            )}
          </button>

          <div className="flex items-center gap-2 flex-1">
            <input
              type="number"
              min="100"
              step="100"
              value={intervalInput}
              onChange={(e) => handleIntervalChange(e.target.value)}
              className="w-24 px-2 py-1.5 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-blue-500 text-center"
            />
            <span className="text-xs text-slate-400">ms</span>
          </div>
        </div>

        <button
          onClick={onSend}
          disabled={!connected}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Send className="w-4 h-4" />
          发送一帧
        </button>
      </div>
    </div>
  );
};

export default StatePanel;
