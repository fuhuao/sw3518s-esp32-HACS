import { useEffect, useRef } from 'react';
import { ScrollText, ArrowUpRight, ArrowDownLeft, Trash2 } from 'lucide-react';
import type { LogEntry } from './types';

interface LogPanelProps {
  logs: LogEntry[];
  onClear: () => void;
}

const LogPanel = ({ logs, onClear }: LogPanelProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('zh-CN', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3,
    } as Intl.DateTimeFormatOptions);
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 backdrop-blur flex flex-col">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <ScrollText className="w-5 h-5 text-purple-400" />
          消息日志
          <span className="text-xs font-normal text-slate-400 ml-1">
            ({logs.length} 条)
          </span>
        </h2>
        <button
          onClick={onClear}
          className="flex items-center gap-1 px-2.5 py-1.5 text-xs text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
          清空
        </button>
      </div>

      <div
        ref={scrollRef}
        className="flex-1 min-h-0 overflow-y-auto bg-slate-950/60 rounded-lg border border-slate-700/50 p-3 font-mono text-xs space-y-1.5"
        style={{ maxHeight: '280px' }}
      >
        {logs.length === 0 ? (
          <div className="text-slate-500 text-center py-8">暂无消息</div>
        ) : (
          logs.map((log) => (
            <div
              key={log.id}
              className={`flex flex-col gap-0.5 pb-1.5 border-b border-slate-800/50 last:border-0 ${
                log.direction === 'send' ? 'pl-2 border-l-2 border-l-green-500/50' : 'pl-2 border-l-2 border-l-blue-500/50'
              }`}
            >
              <div className="flex items-center gap-2 text-[10px]">
                <span className="text-slate-500">{formatTime(log.timestamp)}</span>
                {log.direction === 'send' ? (
                  <span className="flex items-center gap-0.5 text-green-400">
                    <ArrowUpRight className="w-3 h-3" />
                    发送
                  </span>
                ) : (
                  <span className="flex items-center gap-0.5 text-blue-400">
                    <ArrowDownLeft className="w-3 h-3" />
                    接收
                  </span>
                )}
                <span className="text-slate-400 truncate flex-1">{log.topic}</span>
              </div>
              <pre className="text-slate-300 whitespace-pre-wrap break-all text-[11px] leading-relaxed">
                {log.payload}
              </pre>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default LogPanel;
