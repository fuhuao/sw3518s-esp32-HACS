import { useState } from 'react';
import {
  Wifi,
  WifiOff,
  WifiIcon,
  AlertTriangle,
  Save,
  Power,
  PowerOff,
} from 'lucide-react';
import type { MqttConfig, ConnectionStatus } from './types';

interface ConnectionPanelProps {
  config: MqttConfig;
  status: ConnectionStatus;
  onConfigChange: (config: MqttConfig) => void;
  onConnect: () => void;
  onDisconnect: () => void;
  onSaveConfig: () => void;
}

const statusConfig: Record<
  ConnectionStatus,
  { label: string; color: string; icon: React.ElementType; dotColor: string }
> = {
  disconnected: {
    label: '未连接',
    color: 'text-slate-400',
    icon: WifiOff,
    dotColor: 'bg-slate-500',
  },
  connecting: {
    label: '连接中...',
    color: 'text-yellow-400',
    icon: WifiIcon,
    dotColor: 'bg-yellow-500 animate-pulse',
  },
  connected: {
    label: '已连接',
    color: 'text-green-400',
    icon: Wifi,
    dotColor: 'bg-green-500',
  },
  error: {
    label: '连接错误',
    color: 'text-red-400',
    icon: AlertTriangle,
    dotColor: 'bg-red-500',
  },
  reconnecting: {
    label: '重连中...',
    color: 'text-orange-400',
    icon: WifiIcon,
    dotColor: 'bg-orange-500 animate-pulse',
  },
};

const ConnectionPanel = ({
  config,
  status,
  onConfigChange,
  onConnect,
  onDisconnect,
  onSaveConfig,
}: ConnectionPanelProps) => {
  const [showPassword, setShowPassword] = useState(false);
  const { label, color, icon: StatusIcon, dotColor } = statusConfig[status];
  const isConnected = status === 'connected';
  const isBusy = status === 'connecting' || status === 'reconnecting';

  const handleChange = (field: keyof MqttConfig, value: string | number | boolean) => {
    onConfigChange({ ...config, [field]: value });
  };

  return (
    <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-5 backdrop-blur">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-white flex items-center gap-2">
          <Wifi className="w-5 h-5 text-blue-400" />
          MQTT 连接配置
        </h2>
        <div className={`flex items-center gap-2 ${color} font-medium`}>
          <span className={`w-2.5 h-2.5 rounded-full ${dotColor}`} />
          <StatusIcon className="w-4 h-4" />
          {label}
        </div>
      </div>

      <div className="grid grid-cols-12 gap-3">
        <div className="col-span-4">
          <label className="block text-xs text-slate-400 mb-1">Broker 地址</label>
          <input
            type="text"
            value={config.broker}
            onChange={(e) => handleChange('broker', e.target.value)}
            disabled={isConnected || isBusy}
            className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            placeholder="broker.example.com"
          />
        </div>

        <div className="col-span-2">
          <label className="block text-xs text-slate-400 mb-1">端口</label>
          <input
            type="number"
            value={config.port}
            onChange={(e) => handleChange('port', parseInt(e.target.value, 10) || 0)}
            disabled={isConnected || isBusy}
            className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
          />
        </div>

        <div className="col-span-2">
          <label className="block text-xs text-slate-400 mb-1">用户名</label>
          <input
            type="text"
            value={config.username}
            onChange={(e) => handleChange('username', e.target.value)}
            disabled={isConnected || isBusy}
            className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            placeholder="可选"
          />
        </div>

        <div className="col-span-2">
          <label className="block text-xs text-slate-400 mb-1">密码</label>
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={config.password}
              onChange={(e) => handleChange('password', e.target.value)}
              disabled={isConnected || isBusy}
              className="w-full px-3 py-2 pr-16 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
              placeholder="可选"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-300 px-1.5 py-0.5 rounded"
            >
              {showPassword ? '隐藏' : '显示'}
            </button>
          </div>
        </div>

        <div className="col-span-1">
          <label className="block text-xs text-slate-400 mb-1">SSL</label>
          <div className="flex items-center h-[34px]">
            <input
              type="checkbox"
              checked={config.useSSL}
              onChange={(e) => handleChange('useSSL', e.target.checked)}
              disabled={isConnected || isBusy}
              className="w-4 h-4 accent-blue-500"
            />
          </div>
        </div>

        <div className="col-span-12">
          <label className="block text-xs text-slate-400 mb-1">主题前缀</label>
          <input
            type="text"
            value={config.topicPrefix}
            onChange={(e) => handleChange('topicPrefix', e.target.value)}
            disabled={isConnected || isBusy}
            className="w-full px-3 py-2 bg-slate-900/60 border border-slate-600 rounded-lg text-white text-sm font-mono focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
            placeholder="home/sw3518s_charger"
          />
          <p className="text-xs text-slate-500 mt-1">
            state 主题: <span className="font-mono text-slate-400">{config.topicPrefix}/state</span>
            {' · '}
            cmd 主题: <span className="font-mono text-slate-400">{config.topicPrefix}/cmd</span>
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2 mt-4">
        {!isConnected && !isBusy ? (
          <button
            onClick={onConnect}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 text-white text-sm font-medium rounded-lg transition-colors"
          >
            <Power className="w-4 h-4" />
            连接
          </button>
        ) : (
          <button
            onClick={onDisconnect}
            disabled={isBusy}
            className="flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-sm font-medium rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <PowerOff className="w-4 h-4" />
            断开
          </button>
        )}

        <button
          onClick={onSaveConfig}
          className="flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm font-medium rounded-lg transition-colors"
        >
          <Save className="w-4 h-4" />
          保存配置
        </button>
      </div>
    </div>
  );
};

export default ConnectionPanel;
