import { useState, useEffect, useRef, useCallback } from 'react';
import mqtt from 'mqtt';
import type { MqttClient } from 'mqtt';
import { toast } from 'sonner';
import { Cpu } from 'lucide-react';
import ConnectionPanel from './ConnectionPanel';
import StatePanel from './StatePanel';
import IndicatorPanel from './IndicatorPanel';
import LogPanel from './LogPanel';
import {
  DEFAULT_MQTT_CONFIG,
  DEFAULT_CHARGER_STATE,
} from './types';
import type {
  MqttConfig,
  ChargerState,
  ConnectionStatus,
  LogEntry,
  ChargerCmd,
  ProtoKey,
} from './types';

const STORAGE_KEY = 'sw3518s_mqtt_config';

const MqttSimulatorPage = () => {
  const [config, setConfig] = useState<MqttConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return { ...DEFAULT_MQTT_CONFIG, ...JSON.parse(saved) };
    } catch {
      // ignore
    }
    return DEFAULT_MQTT_CONFIG;
  });

  const [status, setStatus] = useState<ConnectionStatus>('disconnected');
  const [chargerState, setChargerState] = useState<ChargerState>(DEFAULT_CHARGER_STATE);
  const [autoReport, setAutoReport] = useState(false);
  const [reportInterval, setReportInterval] = useState(1000);
  const [logs, setLogs] = useState<LogEntry[]>([]);

  const clientRef = useRef<MqttClient | null>(null);
  const reportTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const logIdRef = useRef(0);

  const addLog = useCallback((topic: string, direction: 'send' | 'recv', payload: string) => {
    logIdRef.current += 1;
    const entry: LogEntry = {
      id: `log-${logIdRef.current}`,
      timestamp: new Date(),
      topic,
      direction,
      payload,
    };
    setLogs((prev) => [...prev.slice(-199), entry]);
  }, []);

  const publishState = useCallback(() => {
    if (!clientRef.current || clientRef.current.connected) {
      const topic = `${config.topicPrefix}/state`;
      const payload = JSON.stringify(chargerState, null, 2);
      clientRef.current?.publish(topic, payload);
      addLog(topic, 'send', payload);
    }
  }, [config.topicPrefix, chargerState, addLog]);

  const handleConnect = useCallback(() => {
    if (clientRef.current) {
      try {
        clientRef.current.end(true);
      } catch {
        // ignore
      }
      clientRef.current = null;
    }

    const protocol = config.useSSL ? 'wss' : 'ws';
    const url = `${protocol}://${config.broker}:${config.port}/mqtt`;

    setStatus('connecting');

    try {
      const client = mqtt.connect(url, {
        username: config.username || undefined,
        password: config.password || undefined,
        clientId: `sw3518s_sim_${Math.random().toString(36).slice(2, 10)}`,
        reconnectPeriod: 3000,
        connectTimeout: 10000,
      });

      clientRef.current = client;

      client.on('connect', () => {
        setStatus('connected');
        toast.success('MQTT 连接成功');
        const cmdTopic = `${config.topicPrefix}/cmd`;
        client.subscribe(cmdTopic, (err) => {
          if (err) {
            toast.error(`订阅失败: ${err.message}`);
          } else {
            addLog(cmdTopic, 'recv', `[已订阅 ${cmdTopic}]`);
          }
        });
      });

      client.on('reconnect', () => {
        setStatus('reconnecting');
      });

      client.on('error', (err) => {
        setStatus('error');
        toast.error(`MQTT 错误: ${err.message}`);
      });

      client.on('close', () => {
        setStatus('disconnected');
      });

      client.on('message', (topic, message) => {
        const payloadStr = message.toString();
        addLog(topic, 'recv', payloadStr);

        try {
          const cmd: ChargerCmd = JSON.parse(payloadStr);
          if (cmd.cmd === 'output_on') {
            setChargerState((prev) => ({ ...prev, output_en: true }));
            toast.success('收到指令: output_on');
          } else if (cmd.cmd === 'output_off') {
            setChargerState((prev) => ({ ...prev, output_en: false }));
            toast.success('收到指令: output_off');
          } else if (cmd.cmd === 'set_proto') {
            const proto = cmd.proto as ProtoKey;
            const validProtos: ProtoKey[] = ['pd', 'qc', 'scp', 'vooc', 'fcp'];
            if (validProtos.includes(proto)) {
              setChargerState((prev) => ({
                ...prev,
                proto_en: { ...prev.proto_en, [proto]: cmd.enable },
              }));
              toast.success(
                `收到指令: set_proto ${proto}=${cmd.enable ? 'on' : 'off'}`,
              );
            }
          }
        } catch {
          // ignore parse errors for non-json messages
        }
      });
    } catch (err) {
      setStatus('error');
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(`连接失败: ${msg}`);
    }
  }, [config, addLog]);

  const handleDisconnect = useCallback(() => {
    if (clientRef.current) {
      clientRef.current.end(true);
      clientRef.current = null;
    }
    setAutoReport(false);
    setStatus('disconnected');
    toast.info('已断开 MQTT 连接');
  }, []);

  const handleSaveConfig = useCallback(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
      toast.success('配置已保存到本地');
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(`保存失败: ${msg}`);
    }
  }, [config]);

  const handleAutoReportChange = useCallback(
    (enabled: boolean, interval: number) => {
      setAutoReport(enabled);
      setReportInterval(interval);
    },
    [],
  );

  useEffect(() => {
    if (autoReport && status === 'connected') {
      reportTimerRef.current = setInterval(() => {
        publishState();
      }, reportInterval);
    }

    return () => {
      if (reportTimerRef.current) {
        clearInterval(reportTimerRef.current);
        reportTimerRef.current = null;
      }
    };
  }, [autoReport, reportInterval, status, publishState]);

  useEffect(() => {
    return () => {
      if (clientRef.current) {
        clientRef.current.end(true);
      }
      if (reportTimerRef.current) {
        clearInterval(reportTimerRef.current);
      }
    };
  }, []);

  const handleClearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const connected = status === 'connected';

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <div className="max-w-7xl mx-auto p-4 md:p-6">
        <header className="mb-5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-blue-500/20">
            <Cpu className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">SW3518S MQTT 模拟器</h1>
            <p className="text-sm text-slate-400">
              ESP32-S3 + SW3518S PD 快充充电器 · Home Assistant 集成测试工具
            </p>
          </div>
        </header>

        <div className="space-y-4">
          <ConnectionPanel
            config={config}
            status={status}
            onConfigChange={setConfig}
            onConnect={handleConnect}
            onDisconnect={handleDisconnect}
            onSaveConfig={handleSaveConfig}
          />

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
            <div className="lg:col-span-3">
              <StatePanel
                state={chargerState}
                onStateChange={setChargerState}
                autoReport={autoReport}
                reportInterval={reportInterval}
                onAutoReportChange={handleAutoReportChange}
                onSend={publishState}
                connected={connected}
              />
            </div>
            <div className="lg:col-span-2">
              <IndicatorPanel
                outputEn={chargerState.output_en}
                protoEn={chargerState.proto_en}
              />
            </div>
          </div>

          <LogPanel logs={logs} onClear={handleClearLogs} />
        </div>

        <footer className="mt-6 text-center text-xs text-slate-500">
          SW3518S Charger MQTT Simulator · v1.0 · 浏览器端通过 WebSocket 连接 MQTT Broker
        </footer>
      </div>
    </div>
  );
};

export default MqttSimulatorPage;
