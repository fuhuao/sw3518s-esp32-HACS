import React from 'react';
import { Route, Routes } from 'react-router-dom';
import MqttSimulatorPage from './pages/MqttSimulator/MqttSimulatorPage';
import NotFound from './pages/NotFound/NotFound';

const RoutesComponent = () => {
  return (
    <Routes>
      <Route index element={<MqttSimulatorPage />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default RoutesComponent;
